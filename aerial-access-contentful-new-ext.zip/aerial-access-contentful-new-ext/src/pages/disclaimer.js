import * as React from 'react';
import DisclaimerLayout from "../components/layout-disclaimer"

const DisclaimerPage = () => {
  return <DisclaimerLayout />;
};

export default DisclaimerPage;
