import * as React from 'react';
import AvLayout from '../components/layout-av';


const AvPage = () => {
  return  <AvLayout />;
};

export default AvPage;