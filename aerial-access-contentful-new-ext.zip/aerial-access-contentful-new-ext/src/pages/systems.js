import * as React from 'react';
import LayoutSystemsHome from '../components/layout-systems-home';

const SystemPage = () => {
  return <LayoutSystemsHome />;
};

export default SystemPage;
