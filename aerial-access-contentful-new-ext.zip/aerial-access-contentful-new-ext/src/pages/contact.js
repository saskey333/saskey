import * as React from 'react';
import ContactLayout from '../components/layout-contact';

const ContactPage = () => {
  return <ContactLayout />;
};

export default ContactPage;
