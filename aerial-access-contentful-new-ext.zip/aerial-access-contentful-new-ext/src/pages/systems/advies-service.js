import * as React from 'react';
import LayoutSystemsAdvies from '../../components/layout-systems-advies';

const AdviesServicePage = () => {
  return <LayoutSystemsAdvies />;
};

export default AdviesServicePage;
