import "./src/styles/styles.scss"

// exports.onRouteUpdate = () => {
//     window.__navigatingToLink = false;
//   };